---
name: to-tickets
display_name: "拆成工单"
display_name_en: "To Tickets"
description: "该技能用于把一份计划、规格说明或当前对话拆成一组曳光弹（tracer bullet）工单，每张工单都声明自己的阻塞边（blocking edge），并发布到已配置的追踪器（本地是每张工单一个文件、边写成文本，真实追踪器上则用原生阻塞链接）。适用于「拆工单」「切成任务」「分成 ticket」「拆成可执行的步骤」「to-tickets」这类需求。"
description_zh: "把计划或规格拆成一组曳光弹工单，每张标出阻塞关系"
description_en: "Break a plan or spec into tracer-bullet tickets, each declaring its blocking edges."
category: development-tools
version: 1.0.0
author: "大漠"
disable-model-invocation: true
agent_created: true
---

# 拆成工单（to-tickets）

把一份计划、规格说明或对话拆成一组**工单（ticket）**：曳光弹（tracer bullet）式的垂直切片（vertical slice），每张都声明**阻塞（block）**它的那些工单。

Issue 追踪器和分诊标签词汇应该已经提供给你了。如果没有，提示用户先运行 `setup-matt-pocock-skills` 技能完成本仓库初始化。

## 流程

### 1. 收集上下文

从对话上下文里已有的东西出发。如果用户以参数的形式传了一个引用（一个规格说明路径、一个 issue 编号或 URL），就把它取回来，读它的完整正文和评论。

### 2. 探索代码库（可选）

如果你还没探索过代码库，就探索一下，理解代码的当前状态。工单标题和描述应使用项目领域术语表的词汇，并尊重你正在触碰那块区域里的 ADR。

寻找预先重构（prefactor）代码、让实施更容易的机会。「先让改动变容易，再做那个容易的改动。」

### 3. 起草垂直切片

把工作拆成**曳光弹（tracer bullet）**工单。

<vertical-slice-rules>

- 每个切片都穿过每一层（schema、API、UI、测试）切出一条窄但**完整**的路径：是垂直的，**不是**某一层的横向切片
- 一个完成的切片自身即可演示或可验证
- 每个切片的大小要能装进一个全新的上下文窗口
- 任何预先重构都应最先做

</vertical-slice-rules>

给每张工单配上它的**阻塞边（blocking edge）**：必须先完成、它才能开始的那些别的工单。没有阻塞者的工单可以立刻开始。

**大范围重构（wide refactor）是垂直切片的例外。** 一个**大范围重构**是某一次机械改动（重命名一列、改掉一个共享符号的类型），它的**影响半径（blast radius）**横跨整个代码库，所以单次编辑会同时弄坏成千上万个调用点，没有任何垂直切片能落成绿色。不要把它硬塞进一发曳光弹；把它编排成**扩展–收缩（expand–contract）**。先扩展：把新形式加在旧形式旁边，什么都不坏。然后按影响半径分批迁移调用点（按包、按目录），每批自成一个工单、被「扩展」阻塞；因为旧形式还在，所以一批批下来 CI 保持绿色。最后收缩：在没有调用者剩下后删掉旧形式，这个工单被每一个迁移批次阻塞。当连这些批次自身都无法保持绿色时，保留这个序列，但让它们共用一条集成分支，全部阻塞一个最后的「集成并验证」工单；绿色只在那里被承诺。

### 4. 拷问用户

把提议的拆分作为一份编号清单摆出来。对每张工单，展示：

- **标题（Title）**：简短描述性的名字
- **被谁阻塞（Blocked by）**：哪些别的工单（如果有）必须先完成
- **它交付什么（What it delivers）**：这张工单让什么端到端行为跑起来

问用户：

- 粒度感觉对吗？（太粗 / 太细）
- 阻塞边对吗：每张工单是否只依赖那些真正把着它的工单？
- 有没有工单该合并或进一步拆分？

反复迭代，直到用户批准这份拆分。

### 5. 把工单发布到已配置的追踪器

发布已批准的工单。**怎么发**取决于 `setup-matt-pocock-skills` 技能配置的追踪器；两种情况下工单都一样，只是阻塞边的形态不同：

- **本地文件** → 在 `.scratch/<feature-slug>/issues/<NN>-<slug>.md` 下每张工单写一个文件，按依赖顺序从 `01` 开始编号（阻塞者在前）。每个文件的「Blocked by」列出它依赖的编号/标题。使用下面「每工单」的文件模板：一个文件一张工单，绝不合并成单个文件。
- **真实 issue 追踪器（GitHub、Linear 等）** → 按依赖顺序（阻塞者在前）每张工单发布一个 issue，这样每张工单的阻塞边就能引用真实的标识符。在平台有原生阻塞 / 子 issue 关系的地方就用它；否则把每张工单的「Blocked by」设成那些阻塞它的 issue。除非另有指示，打上 `ready-for-agent` 分诊标签；这些工单在构造上就是可供代理领取的。

推进**前沿（frontier）**：任何阻塞者都已完成的工单。对于一条纯线性的链条，那就是从上到下。

**不要**关闭或修改任何父 issue。

<local-ticket-template>

# <NN>: <工单标题>

**What to build:** 这张工单让什么端到端行为跑起来，从用户的视角出发，而不是一份逐层的实施清单。

**Blocked by:** 把着这张工单的那些工单的编号/标题，或者「None (can start immediately)」。

**Status:** ready-for-agent

- [ ] 验收标准 1
- [ ] 验收标准 2

</local-ticket-template>

<issue-template>

## Parent

对追踪器上父 issue 的一个引用（如果来源是一个已有的 issue，否则省略这一节）。

## What to build

这张工单让什么端到端行为跑起来，从用户的视角出发，而不是逐层的实施。

## Acceptance criteria

- [ ] 标准 1
- [ ] 标准 2

## Blocked by

对每张阻塞工单的一个引用，或者「None (can start immediately)」。

</issue-template>

无论哪种形式，都避免具体的文件路径或代码片段：它们很快就过时。例外：如果某个原型产出了一段代码片段，它比散文更精确地编码了某个决策（状态机、reducer、schema、类型形状），就把它内联进去，并简要注明它来自一个原型。裁剪到只剩决策密集的部分，不是一个可运行的 demo，只是重要的那几块。
